package com.example.advancednotepad

import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.advancednotepad.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.fabNewNote.setOnClickListener {
            showCreateNoteDialog()
        }
    }

    private fun showCreateNoteDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_create_note, null)
        AlertDialog.Builder(this)
            .setTitle("Create New Note")
            .setView(dialogView)
            .setPositiveButton("Create") { dialog, _ ->
                // TODO: Save note logic
                dialog.dismiss()
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }
}
